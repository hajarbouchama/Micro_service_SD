package ma.bouchama.bankaccountservice.service;

import ma.bouchama.bankaccountservice.dto.BankAccountRequestDTO;
import ma.bouchama.bankaccountservice.dto.BankAccountResponseDTO;

public interface AccountService {
    BankAccountResponseDTO addAccount(BankAccountRequestDTO bankAccountDTO);

    BankAccountResponseDTO updateAccount(String id, BankAccountRequestDTO bankAccountDTO);
}

