package ma.bouchama.bankaccountservice.enums;

public enum AccountType {
    CURRENT_ACCOUNT, SAVING_ACCOUNT
}
