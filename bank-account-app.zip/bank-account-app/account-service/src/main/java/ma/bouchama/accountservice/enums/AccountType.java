package ma.bouchama.accountservice.enums;

public enum AccountType {
    CURRENT_ACCOUNT, SAVING_ACCOUNT
}
